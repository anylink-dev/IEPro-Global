#!/usr/bin/python
# -*- coding: UTF-8 -*-
# IEPro third-party web deploy. No arguments.
import json
import os
import shutil
import xml.etree.ElementTree as ET

if os.path.exists('/opt/sdmwebs/'):
    shutil.rmtree('/opt/sdmwebs/')

os.system('unzip -o ./sdmwebs.zip -d /opt/')
os.system('chmod 755 -R /opt/sdmwebs/web/')

serialNumber = ''
if os.path.exists('/etc/devuaid.d'):
    fp = open('/etc/devuaid.d', 'rb')
    lines = fp.readlines()
    fp.close()
    if lines:
        serialNumber = lines[0].strip()

agentVersion = ''
if os.path.exists('/opt/agent/agentbasic'):
    p = os.popen('/opt/agent/agentbasic -v', 'r')
    data = p.read()
    p.close()
    parts = data.split(' ')
    if len(parts) >= 4:
        agentVersion = 'V' + parts[1] + '.' + parts[3][0:-1]

common_path = '/opt/sdmwebs/web/conf/Common.xml'
web_conf = '/opt/sdmwebs/web/conf'
agent_mqtt = '/opt/agent/MqttConfig.json'
web_mqtt = web_conf + '/MqttConfig.json'
def _json_load(path):
    fp = open(path, 'rb')
    obj = json.loads(fp.read())
    fp.close()
    return obj


def _json_dump(path, obj):
    fp = open(path, 'w')
    fp.write(json.dumps(obj, indent=2, ensure_ascii=False))
    fp.close()


if os.path.exists(agent_mqtt) and os.path.exists(web_mqtt):
    try:
        amqtt = _json_load(agent_mqtt)
        wmqtt = _json_load(web_mqtt)
        if not isinstance(wmqtt, dict):
            wmqtt = {}
        cid = amqtt.get('client_id')
        wmqtt['client_id'] = '' if cid is None else cid
        if amqtt.get('host'):
            wmqtt['host'] = amqtt.get('host')
        _json_dump(web_mqtt, wmqtt)
        host = amqtt.get('host') or ''
        if host and os.path.exists(common_path):
            tree = ET.parse(common_path)
            node = tree.find('MqttAddress')
            if node is not None:
                node.text = host
            tree.write(common_path, xml_declaration='true')
    except Exception:
        pass

agent_pt = '/opt/agent/PointTable.json'
web_pt = web_conf + '/PointTable.json'
if os.path.exists(agent_pt) and os.path.exists(web_pt):
    try:
        apt = _json_load(agent_pt)
        wpt = _json_load(web_pt)
        if not isinstance(wpt, dict):
            wpt = {'name': 'PointTable', 'devices': []}
        uid = apt.get('uniqueId')
        wpt['uniqueId'] = '' if uid is None else uid
        _json_dump(web_pt, wpt)
    except Exception:
        pass

if os.path.exists(common_path):
    tree = ET.parse(common_path)
    if serialNumber:
        node = tree.find('SerialNumber')
        if node is not None:
            node.text = serialNumber
    if agentVersion:
        node = tree.find('AgentVersion')
        if node is not None:
            node.text = agentVersion
    tree.write(common_path, xml_declaration='true')

print 'Successfully!'
