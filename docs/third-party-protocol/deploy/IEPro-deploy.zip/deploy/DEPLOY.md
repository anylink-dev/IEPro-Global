# IE Pro 部署说明 / Deploy Guide

**内部 / Internal**

[中文](#zhong-wen) · [English](#english)

---

## 中文 {#zhong-wen}

本包安装 agent 与 Web 界面。部署脚本**无需参数**。

**部署包：** `IEPro-deploy.zip`  
**版本：** 1.0.0

### 部署

将 `IEPro-deploy.zip` 上传到网关 **`/opt`**（该目录一般已存在），然后解压并部署：

```sh
unzip /opt/IEPro-deploy.zip -d /opt && sh /opt/deploy/deploy.sh
```

看到 `IEPro deploy done` 即完成。请以 root 执行。脚本会覆盖 `/opt/agent`、`/opt/sdmwebs` 和 `/etc/boa`。Web 部署成功后执行 `/etc/init.d/S90boa restart`。

网关需有 `unzip`、`python`、`sh`，根文件系统可写。

### 包内结构

```
deploy/deploy.sh
deploy/agent/deploy.sh
deploy/agent/agent-iepro.zip
deploy/sdmwebs/deploy.py
deploy/sdmwebs/sdmwebs.zip
deploy/sdmwebs/boa-1.1.2.zip
deploy/DEPLOY.md
```

### 部署之后

1. 在网关 LAN 侧打开 Web 界面。
2. 登录：`admin` / `admin`。
3. 界面默认使用与 agent 相同的 MQTT 与 uniqueId。可在 Agent 页按需修改后下发。
4. 添加 Modbus 通道、设备和数据项后下发到 agent。
5. 用 watchdog 启动 agent（见下节）。

### 用 watchdog 启动 agent

部署脚本只安装文件，不会自动拉起 agent。在网关上执行：

```sh
cd /opt/agent
python watchdog.py >/dev/null 2>&1 &
```

`watchdog.py` 会启动 `agentbasic`，并在进程退出后自动拉起。

查看是否已运行：

```sh
ps | grep watchdog
ps | grep agentbasic
```

需要重启 agent 时，先停再启：

```sh
killall watchdog.py
killall agentbasic
cd /opt/agent
python watchdog.py >/dev/null 2>&1 &
```

若设备上已有开机脚本（例如 `/opt/script/SysRun.py` 或 `/etc/init.d/S92_start`），重启网关后也会由该脚本启动 watchdog。本次部署包本身不包含开机脚本。

### 安装路径

| 路径 | 内容 |
|---|---|
| `/opt/agent/` | Agent 与运行时配置 |
| `/opt/sdmwebs/web/` | Web 界面 |
| `/etc/boa/` | Boa Web 服务 |

---

## English {#english}

This package installs the agent and web UI. The deploy script takes **no arguments**.

**Package:** `IEPro-deploy.zip`  
**Version:** 1.0.0

### Deploy

Upload `IEPro-deploy.zip` to **`/opt`** on the gateway (`/opt` is normally already present), then unzip and deploy:

```sh
unzip /opt/IEPro-deploy.zip -d /opt && sh /opt/deploy/deploy.sh
```

Done when the console prints `IEPro deploy done`. Run as root. Existing `/opt/agent`, `/opt/sdmwebs`, and `/etc/boa` are replaced. After a successful web install the script runs `/etc/init.d/S90boa restart`.

The gateway needs `unzip`, `python`, `sh`, and a writable root filesystem.

### Package layout

```
deploy/deploy.sh
deploy/agent/deploy.sh
deploy/agent/agent-iepro.zip
deploy/sdmwebs/deploy.py
deploy/sdmwebs/sdmwebs.zip
deploy/sdmwebs/boa-1.1.2.zip
deploy/DEPLOY.md
```

### After deploy

1. Open the web UI from a PC on the gateway LAN.
2. Sign in: `admin` / `admin`.
3. The UI defaults to the same MQTT and uniqueId as the agent. Change them on the Agent page if needed, then apply.
4. Add Modbus channels, devices, and data items, then apply to the agent.
5. Start the agent with watchdog (see below).

### Start the agent with watchdog

The deploy script installs files only; it does not start the agent. On the gateway:

```sh
cd /opt/agent
python watchdog.py >/dev/null 2>&1 &
```

`watchdog.py` starts `agentbasic` and restarts it if the process exits.

Check that it is running:

```sh
ps | grep watchdog
ps | grep agentbasic
```

To restart the agent, stop then start:

```sh
killall watchdog.py
killall agentbasic
cd /opt/agent
python watchdog.py >/dev/null 2>&1 &
```

If the device already has a boot script (for example `/opt/script/SysRun.py` or `/etc/init.d/S92_start`), a reboot will also start watchdog. This package does not include a boot script.

### Installed paths

| Path | Content |
|---|---|
| `/opt/agent/` | Agent and runtime config |
| `/opt/sdmwebs/web/` | Web UI |
| `/etc/boa/` | Boa web server |
