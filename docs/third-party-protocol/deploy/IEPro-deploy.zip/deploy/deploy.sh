#!/bin/sh
# IEPro third-party: deploy agent + web. No arguments.
current_path=$(cd "$(dirname "$0")"; pwd)
cd "$current_path"

mount -o remount wr / 2>/dev/null
mount -o remount,rw / 2>/dev/null

if [ -d "${current_path}/agent" ]; then
    chmod +x "${current_path}/agent/deploy.sh"
    cd "${current_path}/agent"
    sh ./deploy.sh
    cd "$current_path"
fi

if [ -f "${current_path}/sdmwebs/deploy.py" ]; then
    cd "${current_path}/sdmwebs"
    python ./deploy.py
    cd "$current_path"
    if [ -d /opt/sdmwebs/web/cgi-bin/init ]; then
        cd /opt/sdmwebs/web/cgi-bin/init
        python init.py
    fi
fi

if [ -f "${current_path}/sdmwebs/boa-1.1.2.zip" ]; then
    if [ -d /etc/boa ]; then
        rm -rf /etc/boa
    fi
    cd "${current_path}/sdmwebs"
    unzip -o boa-1.1.2.zip > /dev/null
    if [ -d boa-1.1.2 ]; then
        cp -rf boa-1.1.2 /etc/boa
        rm -rf boa-1.1.2
    fi
    cd "$current_path"
fi

if [ -d /opt/sdmwebs/web ] && [ -f /etc/boa/boa.conf ] && [ -f /etc/init.d/S90boa ]; then
    /etc/init.d/S90boa restart
fi

echo "IEPro deploy done"
