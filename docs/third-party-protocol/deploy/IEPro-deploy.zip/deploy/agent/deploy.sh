#!/bin/bash
#Anylink设备，agentbasic部署脚本，v1.
#

if [ -d "/opt/agent/" ];then
    rm -rf /opt/agent/
fi
unzip agent-iepro.zip
mv ./agent /opt/agent
chmod +x /opt/agent/agentbasic 